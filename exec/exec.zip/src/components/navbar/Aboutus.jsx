const Aboutus = () => {
    return (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', paddingTop: '180px' }}>
            <h1 style={{



                textShadow: '15px 0px 0px #703F13, -1px 0px 0px #703F13, 0px 1px 0px #703F13, 0px -1px 0px #703F13',
                fontWeight: 'bolder',
                fontSize: '110px',
                color: 'white',
                marginBottom: '50px'
            }}>
                C106
            </h1>
            <div>

                <div style={{ display: 'flex', flexDirection: 'row', marginBottom: '30px', justifyContent: 'space-between', }}><img style={{ height: '200px', width: '200px', borderRadius: '999px' }} src="/c106tw.jpg" alt="" /><div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}><p style={{ fontFamily: 'GmarketSansMedium', fontSize: '30px', color: '#703F13', fontWeight: 'bolder' }}>EMBEDDED</p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}>Embedded Sofware Leader  </p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}>Camera Web Soket Manager</p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}>QA Manager</p></div></div>
                <div style={{ display: 'flex', flexDirection: 'row', marginBottom: '30px', justifyContent: 'space-between', }}><div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}><p style={{ fontFamily: 'GmarketSansMedium', fontSize: '30px', color: '#703F13', fontWeight: 'bolder' }}>BACK-END</p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}>Infra Leader</p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}> Project Manager</p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}>Server Enginner</p></div><img style={{ height: '200px', width: '200px', borderRadius: '999px' }} src="/c106mk.jpg" alt="" /></div>
                <div style={{ display: 'flex', flexDirection: 'row', marginBottom: '30px', justifyContent: 'space-between', }}><img style={{ height: '200px', width: '200px', borderRadius: '999px' }} src="/c106jm.jpg" alt="" /><div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}><p style={{ fontFamily: 'GmarketSansMedium', fontSize: '30px', color: '#703F13', fontWeight: 'bolder' }}>BACK-END</p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}>Back-end Leader</p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}>Web Soket Manager</p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}> API Enginner</p></div></div>
                <div style={{ display: 'flex', flexDirection: 'row', marginBottom: '30px', justifyContent: 'space-between', }}><div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}><p style={{ fontFamily: 'GmarketSansMedium', fontSize: '30px', color: '#703F13', fontWeight: 'bolder' }}>EMBEDDED</p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}>C106 Leader</p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}>Embedded Leader</p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}>Hardware Manager</p></div><img style={{ height: '200px', width: '200px', borderRadius: '999px' }} src="/c106js.jpg" alt="" /></div>
                <div style={{ display: 'flex', flexDirection: 'row', marginBottom: '30px', justifyContent: 'space-between', }}><img style={{ height: '200px', width: '200px', borderRadius: '999px' }} src="/c106tb.JPG" alt="" /><div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}><p style={{ fontFamily: 'GmarketSansMedium', fontSize: '30px', color: '#703F13', fontWeight: 'bolder' }}>FRONT-END</p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}>Front-end Leader</p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}>Service Manager</p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}>UI/UX Designer</p></div></div>
                <div style={{ display: 'flex', flexDirection: 'row', marginBottom: '30px', justifyContent: 'space-between', }}><div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}><p style={{ fontFamily: 'GmarketSansMedium', fontSize: '30px', color: '#703F13', fontWeight: 'bolder' }}>FRONT-END</p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}>Front-end Design Leader</p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}>Planning Manager</p><p style={{ fontFamily: 'GmarketSansMedium', fontWeight: 'bolder', fontSize: '15px' }}>User Interpace Manager</p></div><img style={{ height: '200px', width: '200px', marginLeft: '150px', borderRadius: '999px' }} src="/c106wj.jpg" alt="" /></div>

            </div>

        </div >
    );
};
export default Aboutus